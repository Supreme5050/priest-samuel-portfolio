Redemption City Navigator - Live Vendor Stage 1-4 Package

Replace these files:
app/vendor-auth.tsx
app/vendor-center.tsx
app/vendor-dashboard.tsx
app/vendor-products.tsx
app/vendor-chat.tsx
services/commerceLiveService.ts
services/marketOrderService.ts

Run this SQL in Supabase SQL Editor:
sql/rcn_live_vendor_stage_1_4_patch.sql

What this package fixes:
1. Vendor dashboard reads the real active vendor account.
2. Vendor product upload writes to Supabase vendor_products.
3. Customer orders sync to Supabase market_orders and delivery_jobs.
4. Customer/vendor chat writes to Supabase chat_threads and chat_messages.

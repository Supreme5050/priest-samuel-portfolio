import AsyncStorage from "@react-native-async-storage/async-storage";

import { isSupabaseConfigured, supabase } from "@/lib/supabase";

export type LiveSource = "supabase" | "local";

export type LiveResult<T = unknown> = {
  ok: boolean;
  source: LiveSource;
  message: string;
  data?: T;
};

export type VendorAccountInput = {
  ownerName: string;
  phone: string;
  storeName: string;
  category: string;
  area: string;
  address?: string;
  latitude?: number;
  longitude?: number;
};

export type VendorSession = VendorAccountInput & {
  id: string;
  vendorId: string;
  status: "pending" | "approved" | "suspended";
  createdAt: string;
};

export type VendorProductInput = {
  id?: string;
  vendorId: string;
  name: string;
  price: string;
  description?: string;
  category?: string;
  imageUrl?: string;
  inStock?: boolean;
};

export type VendorProductLive = {
  id: string;
  vendorId: string;
  name: string;
  price: string;
  description: string;
  category: string;
  imageUrl?: string;
  inStock: boolean;
  createdAt: string;
};

export type MarketOrderLive = {
  id: string;
  vendorId: string;
  vendorName: string;
  productId: string;
  productName: string;
  customerName: string;
  quantity: number;
  amount: string;
  deliveryArea: string;
  deliveryNote: string;
  deliveryPin: string;
  status: string;
  paymentStatus: string;
  createdAt: string;
  updatedAt: string;
};

export type ChatMessageInput = {
  threadId?: string;
  vendorId: string;
  vendorName?: string;
  customerName?: string;
  productId?: string;
  productName?: string;
  senderRole: "customer" | "vendor";
  message: string;
};

export type ChatMessageLive = {
  id: string;
  threadId: string;
  vendorId: string;
  vendorName: string;
  customerName: string;
  productId?: string;
  productName?: string;
  senderRole: "customer" | "vendor";
  message: string;
  createdAt: string;
};

export type ChatThreadLive = {
  id: string;
  vendorId: string;
  vendorName: string;
  customerName: string;
  productId?: string;
  productName?: string;
  lastMessage: string;
  updatedAt: string;
};

export type DeliveryPersonInput = {
  fullName: string;
  phone: string;
  currentArea: string;
  vehicleType: "walk" | "bike" | "car" | "van";
};

export type DeliveryJob = {
  id: string;
  order_id: string;
  vendor_id?: string;
  vendor_name: string;
  customer_name: string;
  pickup_area: string;
  dropoff_area: string;
  status: string;
  rider_name?: string;
  rider_phone?: string;
  delivery_pin?: string;
  created_at?: string;
};

const STORAGE_KEYS = {
  vendorSession: "rcn.vendor.session.v2",
  vendorProducts: "rcn.vendor.products.v2",
  chatMessages: "rcn.chat.messages.v2",
  chatThreads: "rcn.chat.threads.v2",
  deliveryPerson: "rcn.delivery.person.v2",
  deliveryJobs: "rcn.delivery.jobs.v2",
};

function createTextId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function numberFromPrice(value: string) {
  return Number(String(value).replace(/[^0-9.]/g, "")) || 0;
}

export function formatNaira(value: number) {
  return `₦${Math.round(value).toLocaleString()}`;
}

export function parseNairaAmount(value: string) {
  return Number(String(value).replace(/[^0-9.]/g, "")) || 0;
}

function formatPrice(value: unknown) {
  const amount = typeof value === "number" ? value : Number(value || 0);
  return amount > 0 ? formatNaira(amount) : "₦0";
}

function getSafeVendorId(storeName: string, phone?: string) {
  const slug = storeName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 36);
  const tail = String(phone || Date.now()).replace(/[^0-9]/g, "").slice(-4);
  return `vendor-${slug || "store"}-${tail || Date.now().toString().slice(-4)}`;
}

export function getChatThreadId(input: {
  vendorId: string;
  productId?: string;
  customerName?: string;
}) {
  return `thread-${input.vendorId}-${input.productId || "general"}-${
    input.customerName || "guest"
  }`.replace(/[^a-zA-Z0-9-_]/g, "-");
}

async function readJsonArray<T>(key: string): Promise<T[]> {
  const raw = await AsyncStorage.getItem(key);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeJsonArray<T>(key: string, value: T[]) {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export async function getActiveVendorSession(): Promise<VendorSession | null> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.vendorSession);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as VendorSession;
  } catch {
    return null;
  }
}

export async function setActiveVendorSession(session: VendorSession) {
  await AsyncStorage.setItem(STORAGE_KEYS.vendorSession, JSON.stringify(session));
}

export async function createVendorAccountLive(
  input: VendorAccountInput
): Promise<LiveResult<VendorSession>> {
  const vendorId = getSafeVendorId(input.storeName, input.phone);
  const session: VendorSession = {
    ...input,
    id: createTextId("store"),
    vendorId,
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  await setActiveVendorSession(session);

  if (!isSupabaseConfigured || !supabase) {
    return {
      ok: true,
      source: "local",
      data: session,
      message: "Vendor account saved locally. Supabase is not configured.",
    };
  }

  try {
    const storePayload = {
      vendor_id: session.vendorId,
      owner_name: input.ownerName,
      phone: input.phone,
      store_name: input.storeName,
      category: input.category,
      area: input.area,
      address: input.address || input.area,
      latitude: input.latitude ?? null,
      longitude: input.longitude ?? null,
      status: "pending",
      updated_at: new Date().toISOString(),
    };

    const { error: storeError } = await supabase
      .from("vendor_stores")
      .upsert(storePayload, { onConflict: "vendor_id" });

    if (storeError) throw storeError;

    const { error: vendorError } = await supabase.from("vendors").upsert(
      {
        id: session.vendorId,
        name: input.storeName,
        category: input.category,
        category_label: input.category,
        area: input.area,
        address: input.address || input.area,
        latitude: input.latitude ?? null,
        longitude: input.longitude ?? null,
        phone: input.phone,
        whatsapp: input.phone,
        rating: 4.5,
        is_open: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    );

    if (vendorError) throw vendorError;

    return {
      ok: true,
      source: "supabase",
      data: session,
      message: "Vendor account submitted to Supabase.",
    };
  } catch (error) {
    console.warn("Vendor account Supabase sync failed", error);
    return {
      ok: true,
      source: "local",
      data: session,
      message:
        "Vendor account saved locally. Backend sync failed, but the app can continue.",
    };
  }
}

export async function signInVendorLive(input: {
  phone: string;
  storeName?: string;
}): Promise<LiveResult<VendorSession>> {
  if (isSupabaseConfigured && supabase) {
    try {
      let query = supabase
        .from("vendor_stores")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1);

      if (input.phone.trim()) {
        query = query.eq("phone", input.phone.trim());
      }

      const { data, error } = await query.maybeSingle();

      if (!error && data) {
        const session: VendorSession = {
          id: String(data.id || createTextId("store")),
          vendorId: String(data.vendor_id || data.id),
          ownerName: String(data.owner_name || "Vendor"),
          phone: String(data.phone || input.phone),
          storeName: String(data.store_name || input.storeName || "Vendor Store"),
          category: String(data.category || "General"),
          area: String(data.area || "Redemption City"),
          address: data.address ? String(data.address) : undefined,
          latitude: data.latitude !== null && data.latitude !== undefined ? Number(data.latitude) : undefined,
          longitude: data.longitude !== null && data.longitude !== undefined ? Number(data.longitude) : undefined,
          status: String(data.status || "pending") as VendorSession["status"],
          createdAt: String(data.created_at || new Date().toISOString()),
        };

        await setActiveVendorSession(session);

        return {
          ok: true,
          source: "supabase",
          data: session,
          message: "Vendor signed in from Supabase.",
        };
      }
    } catch (error) {
      console.warn("Vendor sign in Supabase lookup failed", error);
    }
  }

  const localSession = await getActiveVendorSession();
  if (localSession) {
    return {
      ok: true,
      source: "local",
      data: localSession,
      message: "Vendor signed in from local device storage.",
    };
  }

  const demoSession: VendorSession = {
    id: createTextId("store"),
    vendorId: getSafeVendorId(input.storeName || "Demo Vendor", input.phone),
    ownerName: "Demo Vendor",
    phone: input.phone,
    storeName: input.storeName || "Demo Vendor Store",
    category: "General",
    area: "Redemption City",
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  await setActiveVendorSession(demoSession);

  return {
    ok: true,
    source: "local",
    data: demoSession,
    message: "Demo vendor session created locally.",
  };
}

function rowToProduct(row: any): VendorProductLive {
  return {
    id: String(row.id),
    vendorId: String(row.vendor_id || row.vendorId || ""),
    name: String(row.name || "Product"),
    price: formatPrice(row.price),
    description: String(row.description || "Vendor product"),
    category: String(row.category || row.unit || "General"),
    imageUrl: row.image_url ? String(row.image_url) : undefined,
    inStock: row.in_stock !== false,
    createdAt: String(row.created_at || row.createdAt || new Date().toISOString()),
  };
}

export async function getVendorProductsLive(
  vendorId: string
): Promise<VendorProductLive[]> {
  const localProducts = (await readJsonArray<VendorProductLive>(
    STORAGE_KEYS.vendorProducts
  )).filter((product) => product.vendorId === vendorId);

  if (!isSupabaseConfigured || !supabase) return localProducts;

  try {
    const { data, error } = await supabase
      .from("vendor_products")
      .select("*")
      .eq("vendor_id", vendorId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    if (!data || data.length === 0) return localProducts;

    return data.map(rowToProduct);
  } catch (error) {
    console.warn("Vendor products Supabase load failed", error);
    return localProducts;
  }
}

export async function createVendorProductLive(
  input: VendorProductInput
): Promise<LiveResult<VendorProductLive>> {
  const productId = input.id || createTextId("product");
  const localProduct: VendorProductLive = {
    id: productId,
    vendorId: input.vendorId,
    name: input.name,
    price: input.price.startsWith("₦") ? input.price : `₦${input.price}`,
    description: input.description || input.category || "Vendor product",
    category: input.category || "General",
    imageUrl: input.imageUrl || undefined,
    inStock: input.inStock !== false,
    createdAt: new Date().toISOString(),
  };

  const currentProducts = await readJsonArray<VendorProductLive>(
    STORAGE_KEYS.vendorProducts
  );
  await writeJsonArray(STORAGE_KEYS.vendorProducts, [
    localProduct,
    ...currentProducts.filter((product) => product.id !== productId),
  ]);

  if (!isSupabaseConfigured || !supabase) {
    return {
      ok: true,
      source: "local",
      data: localProduct,
      message: "Product saved locally. Supabase is not configured.",
    };
  }

  try {
    const { error } = await supabase.from("vendor_products").upsert(
      {
        id: productId,
        vendor_id: input.vendorId,
        name: input.name,
        description: input.description || input.category || "Vendor product",
        category: input.category || "General",
        price: numberFromPrice(input.price),
        unit: "item",
        image_url: input.imageUrl || null,
        in_stock: input.inStock !== false,
      },
      { onConflict: "id" }
    );

    if (error) throw error;

    return {
      ok: true,
      source: "supabase",
      data: localProduct,
      message: "Product uploaded to Supabase.",
    };
  } catch (error) {
    console.warn("Vendor product Supabase sync failed", error);
    return {
      ok: true,
      source: "local",
      data: localProduct,
      message:
        "Product saved locally. Backend sync failed, but the app can continue.",
    };
  }
}

export async function updateVendorProductAvailabilityLive(
  productId: string,
  inStock: boolean
): Promise<LiveResult> {
  const currentProducts = await readJsonArray<VendorProductLive>(
    STORAGE_KEYS.vendorProducts
  );
  await writeJsonArray(
    STORAGE_KEYS.vendorProducts,
    currentProducts.map((product) =>
      product.id === productId ? { ...product, inStock } : product
    )
  );

  if (!isSupabaseConfigured || !supabase) {
    return { ok: true, source: "local", message: "Product updated locally." };
  }

  try {
    const { error } = await supabase
      .from("vendor_products")
      .update({ in_stock: inStock })
      .eq("id", productId);

    if (error) throw error;

    return { ok: true, source: "supabase", message: "Product updated." };
  } catch (error) {
    console.warn("Vendor product update failed", error);
    return {
      ok: true,
      source: "local",
      message: "Product updated locally. Backend sync failed.",
    };
  }
}

function rowToOrder(row: any): MarketOrderLive {
  return {
    id: String(row.id),
    vendorId: String(row.vendor_id || ""),
    vendorName: String(row.vendor_name || "Vendor"),
    productId: String(row.product_id || ""),
    productName: String(row.product_name || "Product"),
    customerName: String(row.customer_name || "Guest Customer"),
    quantity: Number(row.quantity || 1),
    amount: String(row.amount || "₦0"),
    deliveryArea: String(row.delivery_area || "Redemption City"),
    deliveryNote: String(row.delivery_note || ""),
    deliveryPin: String(row.delivery_pin || ""),
    status: String(row.status || "paid"),
    paymentStatus: String(row.payment_status || "held"),
    createdAt: String(row.created_at || ""),
    updatedAt: String(row.updated_at || ""),
  };
}

export async function getVendorOrdersLive(vendorId: string): Promise<MarketOrderLive[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from("market_orders")
      .select("*")
      .eq("vendor_id", vendorId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return (data || []).map(rowToOrder);
  } catch (error) {
    console.warn("Vendor orders Supabase load failed", error);
    return [];
  }
}

export async function updateMarketOrderStatusLive(
  orderId: string,
  status: string,
  paymentStatus?: string
): Promise<LiveResult> {
  if (!isSupabaseConfigured || !supabase) {
    return { ok: true, source: "local", message: "Order status updated locally." };
  }

  try {
    const payload: Record<string, unknown> = {
      status,
      updated_at: new Date().toISOString(),
    };

    if (paymentStatus) payload.payment_status = paymentStatus;

    const { error } = await supabase
      .from("market_orders")
      .update(payload)
      .eq("id", orderId);

    if (error) throw error;

    await supabase
      .from("delivery_jobs")
      .update({
        status: status === "out_for_delivery" ? "available" : status,
        updated_at: new Date().toISOString(),
      })
      .eq("order_id", orderId);

    return { ok: true, source: "supabase", message: "Order updated." };
  } catch (error) {
    console.warn("Order status Supabase update failed", error);
    return {
      ok: true,
      source: "local",
      message: "Order updated locally. Backend sync failed.",
    };
  }
}

export async function syncMarketOrderToBackend(order: any): Promise<void> {
  if (!isSupabaseConfigured || !supabase) return;

  try {
    await supabase.from("market_orders").upsert(
      {
        id: order.id,
        vendor_id: order.vendorId,
        vendor_name: order.vendorName,
        product_id: order.productId,
        product_name: order.productName,
        customer_name: order.customerName,
        quantity: order.quantity,
        amount: order.amount,
        delivery_area: order.deliveryArea,
        delivery_note: order.deliveryNote,
        delivery_pin: order.deliveryPin,
        status: order.status,
        payment_status: order.paymentStatus,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    );

    await supabase.from("delivery_jobs").upsert(
      {
        id: `delivery-${order.id}`,
        order_id: order.id,
        vendor_id: order.vendorId,
        vendor_name: order.vendorName,
        customer_name: order.customerName,
        pickup_area: order.vendorName,
        dropoff_area: order.deliveryArea,
        delivery_pin: order.deliveryPin,
        status: order.status === "out_for_delivery" ? "available" : "pending",
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    );
  } catch (error) {
    console.warn("Market order Supabase sync failed", error);
  }
}

function rowToThread(row: any): ChatThreadLive {
  return {
    id: String(row.id),
    vendorId: String(row.vendor_id || ""),
    vendorName: String(row.vendor_name || "Vendor"),
    customerName: String(row.customer_name || "Guest Customer"),
    productId: row.product_id ? String(row.product_id) : undefined,
    productName: row.product_name ? String(row.product_name) : undefined,
    lastMessage: String(row.last_message || ""),
    updatedAt: String(row.updated_at || row.created_at || ""),
  };
}

function rowToMessage(row: any): ChatMessageLive {
  return {
    id: String(row.id),
    threadId: String(row.thread_id || ""),
    vendorId: String(row.vendor_id || ""),
    vendorName: String(row.vendor_name || "Vendor"),
    customerName: String(row.customer_name || "Guest Customer"),
    productId: row.product_id ? String(row.product_id) : undefined,
    productName: row.product_name ? String(row.product_name) : undefined,
    senderRole: row.sender_role === "vendor" ? "vendor" : "customer",
    message: String(row.message || ""),
    createdAt: String(row.created_at || new Date().toISOString()),
  };
}

export async function getVendorChatThreadsLive(
  vendorId: string
): Promise<ChatThreadLive[]> {
  const localThreads = (await readJsonArray<ChatThreadLive>(
    STORAGE_KEYS.chatThreads
  )).filter((thread) => thread.vendorId === vendorId);

  if (!isSupabaseConfigured || !supabase) return localThreads;

  try {
    const { data, error } = await supabase
      .from("chat_threads")
      .select("*")
      .eq("vendor_id", vendorId)
      .order("updated_at", { ascending: false });

    if (error) throw error;
    if (!data || data.length === 0) return localThreads;

    return data.map(rowToThread);
  } catch (error) {
    console.warn("Vendor chat threads load failed", error);
    return localThreads;
  }
}

export async function getChatMessagesLive(
  threadId: string
): Promise<ChatMessageLive[]> {
  const localMessages = (await readJsonArray<ChatMessageLive>(
    STORAGE_KEYS.chatMessages
  )).filter((message) => message.threadId === threadId);

  if (!isSupabaseConfigured || !supabase) return localMessages.reverse();

  try {
    const { data, error } = await supabase
      .from("chat_messages")
      .select("*")
      .eq("thread_id", threadId)
      .order("created_at", { ascending: true });

    if (error) throw error;
    if (!data || data.length === 0) return localMessages.reverse();

    return data.map(rowToMessage);
  } catch (error) {
    console.warn("Chat messages load failed", error);
    return localMessages.reverse();
  }
}

export async function sendChatMessageLive(
  input: ChatMessageInput
): Promise<LiveResult<ChatMessageLive>> {
  const threadId =
    input.threadId ||
    getChatThreadId({
      vendorId: input.vendorId,
      productId: input.productId,
      customerName: input.customerName,
    });

  const message: ChatMessageLive = {
    id: createTextId("msg"),
    threadId,
    vendorId: input.vendorId,
    vendorName: input.vendorName || "Vendor",
    customerName: input.customerName || "Guest Customer",
    productId: input.productId || undefined,
    productName: input.productName || undefined,
    senderRole: input.senderRole,
    message: input.message,
    createdAt: new Date().toISOString(),
  };

  const thread: ChatThreadLive = {
    id: threadId,
    vendorId: message.vendorId,
    vendorName: message.vendorName,
    customerName: message.customerName,
    productId: message.productId,
    productName: message.productName,
    lastMessage: message.message,
    updatedAt: message.createdAt,
  };

  const currentMessages = await readJsonArray<ChatMessageLive>(
    STORAGE_KEYS.chatMessages
  );
  await writeJsonArray(STORAGE_KEYS.chatMessages, [message, ...currentMessages]);

  const currentThreads = await readJsonArray<ChatThreadLive>(STORAGE_KEYS.chatThreads);
  await writeJsonArray(STORAGE_KEYS.chatThreads, [
    thread,
    ...currentThreads.filter((item) => item.id !== thread.id),
  ]);

  if (!isSupabaseConfigured || !supabase) {
    return { ok: true, source: "local", data: message, message: "Message saved locally." };
  }

  try {
    const { error: threadError } = await supabase.from("chat_threads").upsert(
      {
        id: threadId,
        vendor_id: message.vendorId,
        vendor_name: message.vendorName,
        customer_name: message.customerName,
        product_id: message.productId || null,
        product_name: message.productName || null,
        last_message: message.message,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    );

    if (threadError) throw threadError;

    const { error: messageError } = await supabase.from("chat_messages").insert({
      id: message.id,
      thread_id: threadId,
      vendor_id: message.vendorId,
      vendor_name: message.vendorName,
      customer_name: message.customerName,
      product_id: message.productId || null,
      product_name: message.productName || null,
      sender_role: message.senderRole,
      message: message.message,
    });

    if (messageError) throw messageError;

    return { ok: true, source: "supabase", data: message, message: "Message saved to Supabase." };
  } catch (error) {
    console.warn("Chat Supabase sync failed", error);
    return {
      ok: true,
      source: "local",
      data: message,
      message: "Message saved locally. Backend sync failed.",
    };
  }
}

export async function registerDeliveryPersonLive(
  input: DeliveryPersonInput
): Promise<LiveResult> {
  const riderId = createTextId("rider");
  const profile = {
    id: riderId,
    full_name: input.fullName,
    phone: input.phone,
    current_area: input.currentArea,
    vehicle_type: input.vehicleType,
    status: "available",
    created_at: new Date().toISOString(),
  };

  await AsyncStorage.setItem(STORAGE_KEYS.deliveryPerson, JSON.stringify(profile));

  if (!isSupabaseConfigured || !supabase) {
    return { ok: true, source: "local", message: "Delivery profile saved locally.", data: profile };
  }

  try {
    const { error } = await supabase.from("delivery_people").insert(profile);
    if (error) throw error;
    return { ok: true, source: "supabase", message: "Delivery profile saved to Supabase.", data: profile };
  } catch (error) {
    console.warn("Delivery profile Supabase sync failed", error);
    return { ok: true, source: "local", message: "Delivery profile saved locally. Backend sync failed.", data: profile };
  }
}

export async function getDeliveryJobsLive(): Promise<DeliveryJob[]> {
  const fallbackJobs: DeliveryJob[] = [
    {
      id: "job-demo-1",
      order_id: "RCN-900122",
      vendor_name: "CRM Kitchen",
      customer_name: "Sis. Amaka",
      pickup_area: "CRM Kitchen / Macedonia Road",
      dropoff_area: "Haggai Estate Gate",
      status: "available",
      delivery_pin: "4821",
      created_at: new Date().toISOString(),
    },
    {
      id: "job-demo-2",
      order_id: "RCN-900125",
      vendor_name: "Comfort Supermarket",
      customer_name: "Bro. Tobi",
      pickup_area: "Comfort Palace / CRM Supermarket",
      dropoff_area: "ICT Plaza Area",
      status: "available",
      delivery_pin: "7394",
      created_at: new Date().toISOString(),
    },
  ];

  if (!isSupabaseConfigured || !supabase) return fallbackJobs;

  try {
    const { data, error } = await supabase
      .from("delivery_jobs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(30);

    if (error || !data || data.length === 0) return fallbackJobs;
    return data as DeliveryJob[];
  } catch (error) {
    console.warn("Delivery jobs Supabase load failed", error);
    return fallbackJobs;
  }
}

export async function acceptDeliveryJobLive(input: {
  jobId: string;
  riderName: string;
  riderPhone: string;
}): Promise<LiveResult> {
  const currentJobs = await readJsonArray<DeliveryJob>(STORAGE_KEYS.deliveryJobs);
  await writeJsonArray(STORAGE_KEYS.deliveryJobs, [
    {
      id: input.jobId,
      order_id: input.jobId,
      vendor_name: "Assigned vendor",
      customer_name: "Assigned customer",
      pickup_area: "Vendor location",
      dropoff_area: "Customer destination",
      status: "accepted",
      rider_name: input.riderName,
      rider_phone: input.riderPhone,
      created_at: new Date().toISOString(),
    },
    ...currentJobs,
  ]);

  if (!isSupabaseConfigured || !supabase) {
    return { ok: true, source: "local", message: "Delivery job accepted locally." };
  }

  try {
    const { error } = await supabase
      .from("delivery_jobs")
      .update({
        status: "accepted",
        rider_name: input.riderName,
        rider_phone: input.riderPhone,
        accepted_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", input.jobId);

    if (error) throw error;
    return { ok: true, source: "supabase", message: "Delivery job accepted in Supabase." };
  } catch (error) {
    console.warn("Accept delivery job Supabase sync failed", error);
    return { ok: true, source: "local", message: "Delivery job accepted locally. Backend sync failed." };
  }
}

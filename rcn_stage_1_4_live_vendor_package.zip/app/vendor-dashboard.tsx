import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import {
  formatNaira,
  getActiveVendorSession,
  getVendorChatThreadsLive,
  getVendorOrdersLive,
  getVendorProductsLive,
  parseNairaAmount,
  updateMarketOrderStatusLive,
  type ChatThreadLive,
  type MarketOrderLive,
  type VendorProductLive,
  type VendorSession,
} from "@/services/commerceLiveService";

type VendorTab = "Dashboard" | "Orders" | "Products" | "Wallet" | "Profile";

const COLORS = {
  bg: "#F7F8F6",
  card: "#FFFFFF",
  text: "#111827",
  muted: "#6B7280",
  border: "#E5E7EB",
  primary: "#063F2C",
  primaryLight: "#E8F5EF",
  gold: "#D79A2B",
  green: "#079455",
  red: "#B42318",
  redSoft: "#FEF3F2",
  amberSoft: "#FFF5E6",
};

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function formatDate(value: string) {
  if (!value) return "Just now";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function nextStatus(status: string) {
  if (status === "paid") return "accepted";
  if (status === "accepted") return "preparing";
  if (status === "preparing") return "out_for_delivery";
  return status;
}

function statusLabel(status: string) {
  if (status === "paid") return "New order";
  if (status === "accepted") return "Accepted";
  if (status === "preparing") return "Preparing";
  if (status === "out_for_delivery") return "Ready for rider";
  if (status === "completed") return "Delivered";
  return status.replace(/_/g, " ");
}

function actionLabel(status: string) {
  if (status === "paid") return "Accept";
  if (status === "accepted") return "Start preparing";
  if (status === "preparing") return "Ready for pickup";
  return "Done";
}

export default function VendorDashboardScreen() {
  const params = useLocalSearchParams<{ tab?: string }>();
  const initialTab = ["Dashboard", "Orders", "Products", "Wallet", "Profile"].includes(String(params.tab))
    ? (params.tab as VendorTab)
    : "Dashboard";

  const [activeTab, setActiveTab] = useState<VendorTab>(initialTab);
  const [vendor, setVendor] = useState<VendorSession | null>(null);
  const [products, setProducts] = useState<VendorProductLive[]>([]);
  const [orders, setOrders] = useState<MarketOrderLive[]>([]);
  const [threads, setThreads] = useState<ChatThreadLive[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function loadDashboard() {
    setRefreshing(true);
    const session = await getActiveVendorSession();
    setVendor(session);

    if (session) {
      const [liveProducts, liveOrders, liveThreads] = await Promise.all([
        getVendorProductsLive(session.vendorId),
        getVendorOrdersLive(session.vendorId),
        getVendorChatThreadsLive(session.vendorId),
      ]);
      setProducts(liveProducts);
      setOrders(liveOrders);
      setThreads(liveThreads);
    } else {
      setProducts([]);
      setOrders([]);
      setThreads([]);
    }

    setRefreshing(false);
  }

  useEffect(() => {
    loadDashboard();
  }, []);

  const summary = useMemo(() => {
    const orderTotal = orders.reduce((total, order) => total + parseNairaAmount(order.amount), 0);
    const pendingEscrow = orders
      .filter((order) => order.paymentStatus === "held")
      .reduce((total, order) => total + parseNairaAmount(order.amount), 0);
    const releasedGross = orders
      .filter((order) => order.paymentStatus === "released")
      .reduce((total, order) => total + parseNairaAmount(order.amount), 0);
    const commission = Math.round(releasedGross * 0.05);

    return {
      orderTotal,
      pendingEscrow,
      releasedGross,
      commission,
      payout: Math.max(0, releasedGross - commission),
      activeProducts: products.filter((product) => product.inStock).length,
      newOrders: orders.filter((order) => ["paid", "accepted", "preparing"].includes(order.status)).length,
    };
  }, [orders, products]);

  async function moveOrder(order: MarketOrderLive) {
    const status = nextStatus(order.status);
    if (status === order.status) return;

    const result = await updateMarketOrderStatusLive(order.id, status);
    await loadDashboard();
    Alert.alert("Order updated", result.message);
  }

  if (!vendor) {
    return (
      <SafeAreaView style={styles.screen}>
        <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />
        <View style={styles.emptyScreen}>
          <Pressable style={styles.backButton} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={24} color={COLORS.text} />
          </Pressable>
          <Ionicons name="storefront-outline" size={44} color={COLORS.primary} />
          <Text style={styles.emptyTitle}>No live vendor account</Text>
          <Text style={styles.emptyText}>Create or sign in to a seller account first. The dashboard will then show your real store details.</Text>
          <Pressable style={styles.mainButton} onPress={() => router.push("/vendor-auth?mode=signup" as any)}>
            <Text style={styles.mainButtonText}>Create seller account</Text>
          </Pressable>
          <Pressable style={styles.secondaryButton} onPress={() => router.push("/vendor-auth?mode=signin" as any)}>
            <Text style={styles.secondaryButtonText}>Sign in</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.bg} />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadDashboard} />}
      >
        <View style={styles.header}>
          <Pressable style={styles.backButton} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={23} color={COLORS.text} />
          </Pressable>
          <View style={styles.avatar}><Text style={styles.avatarText}>{vendor.storeName.slice(0, 2).toUpperCase()}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>{greeting()}, {vendor.ownerName.split(" ")[0]}</Text>
            <Text style={styles.subtitle}>{vendor.storeName} Vendor • {vendor.status}</Text>
          </View>
          <Pressable style={styles.iconCircle} onPress={loadDashboard}>
            <Ionicons name="refresh-outline" size={20} color={COLORS.primary} />
          </Pressable>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.kpiRow}>
          <KpiCard label="Sales" value={formatNaira(summary.orderTotal)} icon="cash-outline" />
          <KpiCard label="Orders" value={String(orders.length)} icon="receipt-outline" />
          <KpiCard label="Products" value={String(products.length)} icon="cube-outline" />
          <KpiCard label="Chats" value={String(threads.length)} icon="chatbubbles-outline" />
        </ScrollView>

        <View style={styles.tabRow}>
          {(["Dashboard", "Orders", "Products", "Wallet", "Profile"] as VendorTab[]).map((tab) => (
            <Pressable key={tab} style={[styles.tabButton, activeTab === tab && styles.tabButtonActive]} onPress={() => setActiveTab(tab)}>
              <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>{tab}</Text>
            </Pressable>
          ))}
        </View>

        {activeTab === "Dashboard" ? (
          <View style={styles.section}>
            <View style={styles.liveBanner}>
              <Ionicons name="radio-outline" size={20} color={COLORS.primary} />
              <Text style={styles.liveBannerText}>Live dashboard is reading your active seller account and Supabase records.</Text>
            </View>

            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Store Overview</Text>
              <InfoRow label="Store" value={vendor.storeName} />
              <InfoRow label="Owner" value={vendor.ownerName} />
              <InfoRow label="Phone" value={vendor.phone} />
              <InfoRow label="Area" value={vendor.area} />
              <InfoRow label="Status" value={vendor.status} />
            </View>

            <View style={styles.quickGrid}>
              <QuickAction title="Add product" icon="add-circle-outline" onPress={() => router.push("/vendor-products" as any)} />
              <QuickAction title="View orders" icon="receipt-outline" onPress={() => setActiveTab("Orders")} />
              <QuickAction title="Customer chat" icon="chatbubbles-outline" onPress={() => router.push(`/vendor-chat?role=vendor&vendorId=${vendor.vendorId}&vendorName=${encodeURIComponent(vendor.storeName)}` as any)} />
              <QuickAction title="Vendor location" icon="location-outline" onPress={() => Alert.alert("Vendor location", `${vendor.storeName}\n${vendor.address || vendor.area}`)} />
            </View>
          </View>
        ) : null}

        {activeTab === "Orders" ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Live Orders</Text>
            {orders.length === 0 ? <EmptyBlock title="No live orders yet" text="When a customer checks out, the order will appear here from market_orders." /> : null}
            {orders.map((order) => (
              <View key={order.id} style={styles.orderCard}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.orderRef}>{order.id}</Text>
                  <Text style={styles.orderTitle}>{order.productName}</Text>
                  <Text style={styles.orderMeta}>{order.customerName} • {order.deliveryArea}</Text>
                  <Text style={styles.orderMeta}>PIN: {order.deliveryPin || "----"} • {formatDate(order.createdAt)}</Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={styles.orderAmount}>{order.amount}</Text>
                  <View style={styles.statusBadge}><Text style={styles.statusBadgeText}>{statusLabel(order.status)}</Text></View>
                  {["paid", "accepted", "preparing"].includes(order.status) ? (
                    <Pressable style={styles.smallButton} onPress={() => moveOrder(order)}>
                      <Text style={styles.smallButtonText}>{actionLabel(order.status)}</Text>
                    </Pressable>
                  ) : null}
                </View>
              </View>
            ))}
          </View>
        ) : null}

        {activeTab === "Products" ? (
          <View style={styles.section}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Products</Text>
              <Pressable onPress={() => router.push("/vendor-products" as any)}><Text style={styles.linkText}>Add product</Text></Pressable>
            </View>
            {products.length === 0 ? <EmptyBlock title="No products uploaded" text="Upload products to vendor_products and they can show in Market Hub." /> : null}
            {products.map((product) => (
              <View key={product.id} style={styles.productRow}>
                <View style={styles.productIcon}><Ionicons name="cube-outline" size={22} color={COLORS.primary} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.productName}>{product.name}</Text>
                  <Text style={styles.productMeta}>{product.category} • {product.inStock ? "Active" : "Off"}</Text>
                </View>
                <Text style={styles.productPrice}>{product.price}</Text>
              </View>
            ))}
          </View>
        ) : null}

        {activeTab === "Wallet" ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Wallet Preview</Text>
            <WalletRow label="Pending escrow" value={formatNaira(summary.pendingEscrow)} />
            <WalletRow label="Released gross" value={formatNaira(summary.releasedGross)} />
            <WalletRow label="App commission preview" value={formatNaira(summary.commission)} />
            <WalletRow label="Available payout" value={formatNaira(summary.payout)} bold />
          </View>
        ) : null}

        {activeTab === "Profile" ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Vendor Profile</Text>
            <View style={styles.card}>
              <InfoRow label="Vendor ID" value={vendor.vendorId} />
              <InfoRow label="Store name" value={vendor.storeName} />
              <InfoRow label="Category" value={vendor.category} />
              <InfoRow label="Address" value={vendor.address || vendor.area} />
              <InfoRow label="Phone" value={vendor.phone} />
            </View>
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

function KpiCard({ label, value, icon }: { label: string; value: string; icon: keyof typeof Ionicons.glyphMap }) {
  return <View style={styles.kpiCard}><View style={styles.kpiIcon}><Ionicons name={icon} size={22} color={COLORS.primary} /></View><Text style={styles.kpiLabel}>{label}</Text><Text style={styles.kpiValue}>{value}</Text></View>;
}
function QuickAction({ title, icon, onPress }: { title: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) { return <Pressable style={styles.quickAction} onPress={onPress}><Ionicons name={icon} size={22} color={COLORS.primary} /><Text style={styles.quickActionText}>{title}</Text></Pressable>; }
function InfoRow({ label, value }: { label: string; value: string }) { return <View style={styles.infoRow}><Text style={styles.infoLabel}>{label}</Text><Text style={styles.infoValue}>{value}</Text></View>; }
function WalletRow({ label, value, bold }: { label: string; value: string; bold?: boolean }) { return <View style={styles.walletRow}><Text style={styles.infoLabel}>{label}</Text><Text style={[styles.walletValue, bold && { color: COLORS.primary, fontSize: 22 }]}>{value}</Text></View>; }
function EmptyBlock({ title, text }: { title: string; text: string }) { return <View style={styles.emptyBlock}><Ionicons name="information-circle-outline" size={24} color={COLORS.primary} /><Text style={styles.emptyBlockTitle}>{title}</Text><Text style={styles.emptyBlockText}>{text}</Text></View>; }

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },
  content: { paddingHorizontal: 18, paddingTop: Platform.OS === "android" ? 10 : 0, paddingBottom: 110 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 4 },
  backButton: { width: 44, height: 44, borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  avatar: { width: 54, height: 54, borderRadius: 28, backgroundColor: COLORS.primary, alignItems: "center", justifyContent: "center" },
  avatarText: { color: COLORS.card, fontSize: 18, fontWeight: "900" },
  title: { color: COLORS.text, fontSize: 21, fontWeight: "900" },
  subtitle: { color: COLORS.muted, fontSize: 13, fontWeight: "800", marginTop: 3 },
  iconCircle: { width: 44, height: 44, borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  kpiRow: { gap: 12, paddingVertical: 18 },
  kpiCard: { width: 150, borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 15 },
  kpiIcon: { width: 42, height: 42, borderRadius: 16, backgroundColor: COLORS.primaryLight, alignItems: "center", justifyContent: "center" },
  kpiLabel: { color: COLORS.muted, fontSize: 12, fontWeight: "800", marginTop: 12 },
  kpiValue: { color: COLORS.text, fontSize: 22, fontWeight: "900", marginTop: 5 },
  tabRow: { flexDirection: "row", gap: 8, flexWrap: "wrap", marginBottom: 14 },
  tabButton: { paddingVertical: 10, paddingHorizontal: 13, borderRadius: 999, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border },
  tabButtonActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  tabText: { color: COLORS.muted, fontSize: 12, fontWeight: "900" },
  tabTextActive: { color: COLORS.card },
  section: { gap: 12 },
  liveBanner: { borderRadius: 18, backgroundColor: COLORS.primaryLight, padding: 13, flexDirection: "row", gap: 10, alignItems: "center" },
  liveBannerText: { flex: 1, color: COLORS.primary, fontSize: 12, lineHeight: 18, fontWeight: "800" },
  card: { borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 16 },
  sectionTitle: { color: COLORS.text, fontSize: 18, fontWeight: "900" },
  sectionHeaderRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  linkText: { color: COLORS.primary, fontSize: 13, fontWeight: "900" },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  quickAction: { width: "48%", minHeight: 82, borderRadius: 20, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 14, gap: 8 },
  quickActionText: { color: COLORS.text, fontSize: 13, fontWeight: "900" },
  infoRow: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border, flexDirection: "row", justifyContent: "space-between", gap: 12 },
  infoLabel: { color: COLORS.muted, fontSize: 12, fontWeight: "800" },
  infoValue: { flex: 1, textAlign: "right", color: COLORS.text, fontSize: 13, fontWeight: "900" },
  orderCard: { borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 14, flexDirection: "row", gap: 10 },
  orderRef: { color: COLORS.primary, fontSize: 12, fontWeight: "900" },
  orderTitle: { color: COLORS.text, fontSize: 15, fontWeight: "900", marginTop: 4 },
  orderMeta: { color: COLORS.muted, fontSize: 11, fontWeight: "700", marginTop: 3 },
  orderAmount: { color: COLORS.text, fontSize: 14, fontWeight: "900" },
  statusBadge: { marginTop: 8, borderRadius: 999, backgroundColor: COLORS.amberSoft, paddingHorizontal: 9, paddingVertical: 6 },
  statusBadgeText: { color: COLORS.gold, fontSize: 10, fontWeight: "900" },
  smallButton: { marginTop: 8, borderRadius: 999, backgroundColor: COLORS.primary, paddingHorizontal: 10, paddingVertical: 7 },
  smallButtonText: { color: COLORS.card, fontSize: 10, fontWeight: "900" },
  productRow: { borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  productIcon: { width: 42, height: 42, borderRadius: 15, backgroundColor: COLORS.primaryLight, alignItems: "center", justifyContent: "center" },
  productName: { color: COLORS.text, fontSize: 14, fontWeight: "900" },
  productMeta: { color: COLORS.muted, fontSize: 11, fontWeight: "800", marginTop: 3 },
  productPrice: { color: COLORS.primary, fontSize: 14, fontWeight: "900" },
  walletRow: { borderRadius: 20, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  walletValue: { color: COLORS.text, fontSize: 16, fontWeight: "900" },
  emptyBlock: { borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 18 },
  emptyBlockTitle: { color: COLORS.text, fontSize: 16, fontWeight: "900", marginTop: 10 },
  emptyBlockText: { color: COLORS.muted, fontSize: 13, lineHeight: 19, fontWeight: "700", marginTop: 5 },
  emptyScreen: { flex: 1, backgroundColor: COLORS.bg, padding: 22, justifyContent: "center" },
  emptyTitle: { color: COLORS.text, fontSize: 24, fontWeight: "900", marginTop: 16 },
  emptyText: { color: COLORS.muted, fontSize: 14, lineHeight: 21, fontWeight: "700", marginTop: 8 },
  mainButton: { marginTop: 20, height: 52, borderRadius: 16, backgroundColor: COLORS.primary, alignItems: "center", justifyContent: "center" },
  mainButtonText: { color: COLORS.card, fontSize: 14, fontWeight: "900" },
  secondaryButton: { marginTop: 10, height: 52, borderRadius: 16, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  secondaryButtonText: { color: COLORS.text, fontSize: 14, fontWeight: "900" },
});

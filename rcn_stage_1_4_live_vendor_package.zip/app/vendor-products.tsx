import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import {
  createVendorProductLive,
  getActiveVendorSession,
  getVendorProductsLive,
  updateVendorProductAvailabilityLive,
  type VendorProductLive,
  type VendorSession,
} from "@/services/commerceLiveService";

const COLORS = {
  brand: "#1B4332",
  brandDark: "#0B2F22",
  brandSoft: "#EAF4EE",
  background: "#FAFAF7",
  card: "#FFFFFF",
  text: "#14281D",
  muted: "#667085",
  border: "#E7E5DE",
  accent: "#F59E0B",
  success: "#027A48",
  danger: "#B42318",
};

export default function VendorProductsScreen() {
  const [vendor, setVendor] = useState<VendorSession | null>(null);
  const [products, setProducts] = useState<VendorProductLive[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("Food & Essentials");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  async function load() {
    setLoading(true);
    const session = await getActiveVendorSession();
    setVendor(session);

    if (session) {
      const liveProducts = await getVendorProductsLive(session.vendorId);
      setProducts(liveProducts);
    } else {
      setProducts([]);
    }

    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function addProduct() {
    if (!vendor) {
      Alert.alert("Vendor account needed", "Create or sign in to a seller account first.", [
        { text: "Go to sign in", onPress: () => router.push("/vendor-auth?mode=signin" as any) },
      ]);
      return;
    }

    if (!name.trim() || !price.trim()) {
      Alert.alert("Missing details", "Enter product name and price.");
      return;
    }

    try {
      setSaving(true);
      const result = await createVendorProductLive({
        vendorId: vendor.vendorId,
        name: name.trim(),
        price: price.trim(),
        category: category.trim() || vendor.category,
        description: description.trim() || `${name.trim()} from ${vendor.storeName}`,
        imageUrl: imageUrl.trim() || undefined,
        inStock: true,
      });

      setName("");
      setPrice("");
      setDescription("");
      setImageUrl("");
      setShowForm(false);
      await load();
      Alert.alert("Product saved", result.message);
    } finally {
      setSaving(false);
    }
  }

  async function toggleProduct(product: VendorProductLive) {
    await updateVendorProductAvailabilityLive(product.id, !product.inStock);
    await load();
  }

  const activeCount = products.filter((product) => product.inStock).length;

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable style={styles.backButton} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={24} color={COLORS.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>LIVE STORE PRODUCTS</Text>
            <Text style={styles.title}>Products</Text>
            <Text style={styles.subtitle}>{vendor ? vendor.storeName : "No seller signed in"}</Text>
          </View>
        </View>

        {!vendor ? (
          <View style={styles.emptyCard}>
            <Ionicons name="lock-closed-outline" size={28} color={COLORS.brand} />
            <Text style={styles.emptyTitle}>Seller account needed</Text>
            <Text style={styles.emptyText}>Sign in or register before uploading products.</Text>
            <Pressable style={styles.primaryButton} onPress={() => router.push("/vendor-auth?mode=signin" as any)}>
              <Text style={styles.primaryButtonText}>Seller sign in</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={styles.summaryGrid}>
              <StatBox label="All products" value={String(products.length)} icon="cube" />
              <StatBox label="Active" value={String(activeCount)} icon="checkmark-circle" />
            </View>

            <Pressable style={styles.addButton} onPress={() => setShowForm((value) => !value)}>
              <Ionicons name={showForm ? "close-circle" : "add-circle"} size={21} color={COLORS.card} />
              <Text style={styles.addButtonText}>{showForm ? "Close Form" : "Add Product"}</Text>
            </Pressable>

            {showForm ? (
              <View style={styles.formCard}>
                <Text style={styles.formTitle}>New live product</Text>
                <FormInput value={name} onChangeText={setName} placeholder="Product name" />
                <FormInput value={price} onChangeText={setPrice} placeholder="Price, example: ₦1,500" keyboardType="numeric" />
                <FormInput value={category} onChangeText={setCategory} placeholder="Category" />
                <FormInput value={description} onChangeText={setDescription} placeholder="Short description" multiline />
                <FormInput value={imageUrl} onChangeText={setImageUrl} placeholder="Image URL optional" />
                <Pressable style={styles.saveButton} onPress={addProduct} disabled={saving}>
                  <Text style={styles.saveButtonText}>{saving ? "Saving..." : "Save Product to Supabase"}</Text>
                </Pressable>
              </View>
            ) : null}

            <View style={styles.productList}>
              {loading ? <Text style={styles.loadingText}>Loading products...</Text> : null}
              {!loading && products.length === 0 ? (
                <View style={styles.emptyCard}>
                  <Ionicons name="cube-outline" size={28} color={COLORS.brand} />
                  <Text style={styles.emptyTitle}>No products yet</Text>
                  <Text style={styles.emptyText}>Add your first product. It will appear in Supabase vendor_products.</Text>
                </View>
              ) : null}

              {products.map((product) => (
                <View key={product.id} style={styles.productCard}>
                  <View style={styles.productIcon}>
                    <Ionicons name="cube-outline" size={24} color={COLORS.brand} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.productName}>{product.name}</Text>
                    <Text style={styles.productMeta}>{product.category}</Text>
                    <Text style={styles.productDescription}>{product.description}</Text>
                    <Text style={styles.productPrice}>{product.price}</Text>
                  </View>
                  <Pressable
                    style={[styles.statusPill, product.inStock ? styles.activePill : styles.inactivePill]}
                    onPress={() => toggleProduct(product)}
                  >
                    <Text style={[styles.statusText, product.inStock ? styles.activeText : styles.inactiveText]}>
                      {product.inStock ? "Active" : "Off"}
                    </Text>
                  </Pressable>
                </View>
              ))}
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

function FormInput({ value, onChangeText, placeholder, keyboardType, multiline }: { value: string; onChangeText: (value: string) => void; placeholder: string; keyboardType?: "default" | "numeric"; multiline?: boolean }) {
  return (
    <TextInput
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={COLORS.muted}
      keyboardType={keyboardType || "default"}
      multiline={multiline}
      style={[styles.input, multiline && { height: 84, textAlignVertical: "top", paddingTop: 14 }]}
    />
  );
}

function StatBox({ label, value, icon }: { label: string; value: string; icon: keyof typeof Ionicons.glyphMap }) {
  return (
    <View style={styles.statBox}>
      <Ionicons name={icon} size={22} color={COLORS.brand} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingHorizontal: 18, paddingTop: Platform.OS === "android" ? 34 : 56, paddingBottom: 120 },
  header: { flexDirection: "row", alignItems: "center", gap: 13 },
  backButton: { width: 48, height: 48, borderRadius: 999, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  eyebrow: { color: COLORS.brand, fontSize: 11, fontWeight: "900", letterSpacing: 1 },
  title: { marginTop: 3, color: COLORS.text, fontSize: 30, fontWeight: "900" },
  subtitle: { marginTop: 2, color: COLORS.muted, fontSize: 13, fontWeight: "700" },
  summaryGrid: { marginTop: 22, flexDirection: "row", gap: 12 },
  statBox: { flex: 1, borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 15 },
  statValue: { color: COLORS.text, fontSize: 26, fontWeight: "900", marginTop: 8 },
  statLabel: { color: COLORS.muted, fontSize: 12, fontWeight: "800", marginTop: 4 },
  addButton: { marginTop: 18, minHeight: 54, borderRadius: 18, backgroundColor: COLORS.brand, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  addButtonText: { color: COLORS.card, fontSize: 14, fontWeight: "900" },
  formCard: { marginTop: 16, borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 16, gap: 10 },
  formTitle: { color: COLORS.text, fontSize: 18, fontWeight: "900", marginBottom: 2 },
  input: { minHeight: 52, borderRadius: 16, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 14, color: COLORS.text, fontSize: 14, fontWeight: "800" },
  saveButton: { height: 52, borderRadius: 16, backgroundColor: COLORS.accent, alignItems: "center", justifyContent: "center" },
  saveButtonText: { color: COLORS.text, fontSize: 14, fontWeight: "900" },
  productList: { marginTop: 16, gap: 12 },
  productCard: { borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 14, flexDirection: "row", gap: 12, alignItems: "center" },
  productIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: COLORS.brandSoft, alignItems: "center", justifyContent: "center" },
  productName: { color: COLORS.text, fontSize: 15, fontWeight: "900" },
  productMeta: { color: COLORS.muted, fontSize: 12, fontWeight: "800", marginTop: 2 },
  productDescription: { color: COLORS.muted, fontSize: 11, fontWeight: "700", marginTop: 3 },
  productPrice: { color: COLORS.brand, fontSize: 15, fontWeight: "900", marginTop: 5 },
  statusPill: { minWidth: 58, borderRadius: 999, paddingVertical: 8, paddingHorizontal: 10, alignItems: "center" },
  activePill: { backgroundColor: COLORS.brandSoft },
  inactivePill: { backgroundColor: "#FEF3F2" },
  statusText: { fontSize: 11, fontWeight: "900" },
  activeText: { color: COLORS.success },
  inactiveText: { color: COLORS.danger },
  loadingText: { color: COLORS.muted, fontSize: 13, fontWeight: "800" },
  emptyCard: { marginTop: 18, borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 18, alignItems: "flex-start" },
  emptyTitle: { color: COLORS.text, fontSize: 18, fontWeight: "900", marginTop: 10 },
  emptyText: { color: COLORS.muted, fontSize: 13, lineHeight: 20, fontWeight: "700", marginTop: 5 },
  primaryButton: { marginTop: 14, height: 50, borderRadius: 16, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center", paddingHorizontal: 18 },
  primaryButtonText: { color: COLORS.card, fontSize: 14, fontWeight: "900" },
});

import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import {
  getActiveVendorSession,
  getChatMessagesLive,
  getChatThreadId,
  sendChatMessageLive,
  type ChatMessageLive,
  type VendorSession,
} from "@/services/commerceLiveService";

const COLORS = {
  brand: "#1B4332",
  brandDark: "#0B2F22",
  brandSoft: "#EAF4EE",
  background: "#FAFAF7",
  card: "#FFFFFF",
  text: "#14281D",
  muted: "#667085",
  border: "#E7E5DE",
  accent: "#F59E0B",
  success: "#027A48",
  customerBubble: "#F2F4F7",
};

function shortTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "now";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function VendorChatScreen() {
  const params = useLocalSearchParams<{
    vendorId?: string;
    vendorName?: string;
    productId?: string;
    productName?: string;
    customerName?: string;
    role?: string;
  }>();

  const scrollRef = useRef<ScrollView | null>(null);
  const [activeVendor, setActiveVendor] = useState<VendorSession | null>(null);
  const [messages, setMessages] = useState<ChatMessageLive[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);

  const role = params.role === "vendor" ? "vendor" : "customer";
  const vendorId = params.vendorId || activeVendor?.vendorId || "vendor-general";
  const vendorName = params.vendorName || activeVendor?.storeName || "Vendor";
  const customerName = params.customerName || "Guest Customer";
  const productId = params.productId;
  const productName = params.productName;
  const threadId = getChatThreadId({ vendorId, productId, customerName });

  async function load() {
    setLoading(true);
    const session = await getActiveVendorSession();
    setActiveVendor(session);
    const liveMessages = await getChatMessagesLive(threadId);
    setMessages(liveMessages);
    setLoading(false);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 200);
  }

  useEffect(() => {
    load();
  }, [threadId]);

  async function sendMessage() {
    const clean = input.trim();
    if (!clean) return;

    setInput("");
    const result = await sendChatMessageLive({
      threadId,
      vendorId,
      vendorName,
      customerName,
      productId,
      productName,
      senderRole: role,
      message: clean,
    });

    if (result.data) setMessages((current) => [...current, result.data as ChatMessageLive]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);

    if (result.source === "local") {
      console.log("Vendor chat saved locally:", result.message);
    }
  }

  function sendQuickMessage(text: string) {
    setInput(text);
  }

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <View style={styles.header}>
        <Pressable style={styles.backButton} onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={24} color={COLORS.text} />
        </Pressable>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{vendorName.slice(0, 2).toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{role === "vendor" ? customerName : vendorName}</Text>
          <Text style={styles.subtitle}>{productName ? `About ${productName}` : role === "vendor" ? "Customer conversation" : "Vendor conversation"}</Text>
        </View>
        <Pressable style={styles.iconCircle} onPress={load}>
          <Ionicons name="refresh-outline" size={20} color={COLORS.brand} />
        </Pressable>
      </View>

      <ScrollView ref={scrollRef} style={styles.chatArea} contentContainerStyle={styles.chatContent} showsVerticalScrollIndicator={false}>
        <View style={styles.noticeCard}>
          <Ionicons name="cloud-done-outline" size={18} color={COLORS.brand} />
          <Text style={styles.noticeText}>Messages are saved to Supabase chat_messages when connected.</Text>
        </View>

        {loading ? <Text style={styles.loadingText}>Loading messages...</Text> : null}

        {!loading && messages.length === 0 ? (
          <View style={styles.emptyCard}>
            <Ionicons name="chatbubbles-outline" size={26} color={COLORS.brand} />
            <Text style={styles.emptyTitle}>No message yet</Text>
            <Text style={styles.emptyText}>{role === "vendor" ? "Reply to customers from here." : "Ask the vendor about availability, price or pickup location."}</Text>
          </View>
        ) : null}

        {messages.map((message) => {
          const mine = message.senderRole === role;
          return (
            <View key={message.id} style={[styles.messageRow, mine ? styles.messageRowMine : styles.messageRowOther]}>
              <View style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleOther]}>
                <Text style={[styles.sender, mine && styles.senderMine]}>{message.senderRole === "vendor" ? vendorName : message.customerName}</Text>
                <Text style={[styles.messageText, mine && styles.messageTextMine]}>{message.message}</Text>
                <Text style={[styles.messageTime, mine && styles.messageTimeMine]}>{shortTime(message.createdAt)}</Text>
              </View>
            </View>
          );
        })}
      </ScrollView>

      <View style={styles.quickRow}>
        {(role === "customer" ? ["Is it available?", "Where is your shop?", "Can you deliver?"] : ["Available", "Please send location", "Ready for pickup"]).map((item) => (
          <Pressable key={item} style={styles.quickChip} onPress={() => sendQuickMessage(item)}>
            <Text style={styles.quickChipText}>{item}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.inputBar}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder={role === "vendor" ? "Reply customer..." : "Message vendor..."}
          placeholderTextColor={COLORS.muted}
          style={styles.input}
          multiline
        />
        <Pressable style={styles.sendButton} onPress={sendMessage}>
          <Ionicons name="send" size={20} color={COLORS.card} />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  header: { paddingHorizontal: 18, paddingTop: Platform.OS === "android" ? 22 : 56, paddingBottom: 12, flexDirection: "row", alignItems: "center", gap: 11, backgroundColor: COLORS.background, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backButton: { width: 42, height: 42, borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center" },
  avatarText: { color: COLORS.card, fontSize: 15, fontWeight: "900" },
  title: { color: COLORS.text, fontSize: 18, fontWeight: "900" },
  subtitle: { color: COLORS.muted, fontSize: 12, fontWeight: "800", marginTop: 2 },
  iconCircle: { width: 42, height: 42, borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  chatArea: { flex: 1 },
  chatContent: { padding: 16, paddingBottom: 24 },
  noticeCard: { alignSelf: "center", maxWidth: "92%", borderRadius: 999, backgroundColor: COLORS.brandSoft, paddingHorizontal: 12, paddingVertical: 9, flexDirection: "row", gap: 8, alignItems: "center", marginBottom: 16 },
  noticeText: { flex: 1, color: COLORS.brand, fontSize: 11, fontWeight: "800" },
  loadingText: { color: COLORS.muted, fontSize: 13, fontWeight: "800" },
  emptyCard: { borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 18, alignItems: "center" },
  emptyTitle: { color: COLORS.text, fontSize: 17, fontWeight: "900", marginTop: 8 },
  emptyText: { color: COLORS.muted, fontSize: 13, textAlign: "center", lineHeight: 19, fontWeight: "700", marginTop: 5 },
  messageRow: { marginBottom: 12, flexDirection: "row" },
  messageRowMine: { justifyContent: "flex-end" },
  messageRowOther: { justifyContent: "flex-start" },
  bubble: { maxWidth: "82%", borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10 },
  bubbleMine: { backgroundColor: COLORS.brand, borderBottomRightRadius: 6 },
  bubbleOther: { backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, borderBottomLeftRadius: 6 },
  sender: { color: COLORS.brand, fontSize: 10, fontWeight: "900", marginBottom: 4 },
  senderMine: { color: COLORS.brandSoft },
  messageText: { color: COLORS.text, fontSize: 14, lineHeight: 20, fontWeight: "700" },
  messageTextMine: { color: COLORS.card },
  messageTime: { color: COLORS.muted, fontSize: 10, fontWeight: "800", marginTop: 6, alignSelf: "flex-end" },
  messageTimeMine: { color: "#D8EFE2" },
  quickRow: { paddingHorizontal: 14, paddingVertical: 10, flexDirection: "row", gap: 8, borderTopWidth: 1, borderTopColor: COLORS.border },
  quickChip: { borderRadius: 999, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 10, paddingVertical: 8 },
  quickChipText: { color: COLORS.text, fontSize: 11, fontWeight: "800" },
  inputBar: { paddingHorizontal: 14, paddingVertical: 12, flexDirection: "row", alignItems: "flex-end", gap: 10, backgroundColor: COLORS.card, borderTopWidth: 1, borderTopColor: COLORS.border },
  input: { flex: 1, maxHeight: 96, minHeight: 46, borderRadius: 18, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, paddingHorizontal: 14, paddingVertical: 12, color: COLORS.text, fontSize: 14, fontWeight: "700" },
  sendButton: { width: 48, height: 48, borderRadius: 18, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center" },
});

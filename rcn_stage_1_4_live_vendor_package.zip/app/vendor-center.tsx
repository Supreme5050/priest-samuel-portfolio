import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { getActiveVendorSession, type VendorSession } from "@/services/commerceLiveService";

const COLORS = {
  brand: "#1B4332",
  brandDark: "#0B2F22",
  brandSoft: "#EAF4EE",
  background: "#FAFAF7",
  card: "#FFFFFF",
  text: "#14281D",
  muted: "#667085",
  border: "#E7E5DE",
  accent: "#F59E0B",
  accentSoft: "#FFF5E6",
  success: "#027A48",
};

export default function VendorCenterScreen() {
  const [vendor, setVendor] = useState<VendorSession | null>(null);

  useEffect(() => {
    getActiveVendorSession().then(setVendor);
  }, []);

  return (
    <View style={styles.screen}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.background} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable style={styles.headerIconButton} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={24} color={COLORS.text} />
          </Pressable>

          <View style={{ flex: 1 }}>
            <Text style={styles.eyebrow}>REDEMPTION MARKET</Text>
            <Text style={styles.title}>Vendor Center</Text>
            <Text style={styles.subtitle}>Register, manage products, receive orders and chat with customers.</Text>
          </View>
        </View>

        {vendor ? (
          <View style={styles.liveCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{vendor.storeName.slice(0, 2).toUpperCase()}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.liveTitle}>{vendor.storeName}</Text>
              <Text style={styles.liveMeta}>{vendor.ownerName} • {vendor.area}</Text>
              <Text style={styles.liveStatus}>Live session active • {vendor.status}</Text>
            </View>
          </View>
        ) : (
          <View style={styles.heroCard}>
            <Ionicons name="storefront" size={30} color={COLORS.brand} />
            <Text style={styles.heroTitle}>Sell inside Redemption City</Text>
            <Text style={styles.heroText}>Create a real seller profile and start uploading products to Supabase.</Text>
          </View>
        )}

        <View style={styles.actionGrid}>
          <ActionCard title="Create seller account" subtitle="Register store" icon="person-add-outline" onPress={() => router.push("/vendor-auth?mode=signup" as any)} />
          <ActionCard title="Seller sign in" subtitle="Continue by phone" icon="log-in-outline" onPress={() => router.push("/vendor-auth?mode=signin" as any)} />
          <ActionCard title="Dashboard" subtitle="Live store overview" icon="grid-outline" onPress={() => router.push("/vendor-dashboard" as any)} />
          <ActionCard title="Products" subtitle="Upload items" icon="cube-outline" onPress={() => router.push("/vendor-products" as any)} />
          <ActionCard title="Orders" subtitle="Prepare orders" icon="receipt-outline" onPress={() => router.push("/vendor-dashboard?tab=Orders" as any)} />
          <ActionCard title="Chat" subtitle="Customer messages" icon="chatbubbles-outline" onPress={() => router.push("/vendor-chat?role=vendor" as any)} />
        </View>

        <View style={styles.noteCard}>
          <Ionicons name="shield-checkmark-outline" size={22} color={COLORS.brand} />
          <Text style={styles.noteText}>This MVP now uses Supabase for seller accounts, product uploads, market orders and customer chat where available.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function ActionCard({ title, subtitle, icon, onPress }: { title: string; subtitle: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  return (
    <Pressable style={styles.actionCard} onPress={onPress}>
      <View style={styles.actionIcon}><Ionicons name={icon} size={22} color={COLORS.brand} /></View>
      <Text style={styles.actionTitle}>{title}</Text>
      <Text style={styles.actionSubtitle}>{subtitle}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingHorizontal: 18, paddingTop: Platform.OS === "android" ? 22 : 58, paddingBottom: 40 },
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIconButton: { width: 44, height: 44, borderRadius: 18, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center" },
  eyebrow: { color: COLORS.brand, fontSize: 12, fontWeight: "900", letterSpacing: 0.8 },
  title: { color: COLORS.text, fontSize: 30, fontWeight: "900", marginTop: 2 },
  subtitle: { color: COLORS.muted, fontSize: 13, lineHeight: 19, fontWeight: "700", marginTop: 4 },
  heroCard: { marginTop: 20, borderRadius: 26, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 18 },
  heroTitle: { marginTop: 12, color: COLORS.text, fontSize: 24, fontWeight: "900" },
  heroText: { marginTop: 8, color: COLORS.muted, fontSize: 14, lineHeight: 20, fontWeight: "700" },
  liveCard: { marginTop: 20, borderRadius: 24, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 16, flexDirection: "row", gap: 13, alignItems: "center" },
  avatar: { width: 54, height: 54, borderRadius: 27, backgroundColor: COLORS.brand, alignItems: "center", justifyContent: "center" },
  avatarText: { color: COLORS.card, fontSize: 18, fontWeight: "900" },
  liveTitle: { color: COLORS.text, fontSize: 20, fontWeight: "900" },
  liveMeta: { color: COLORS.muted, fontSize: 13, fontWeight: "800", marginTop: 3 },
  liveStatus: { color: COLORS.success, fontSize: 12, fontWeight: "900", marginTop: 5 },
  actionGrid: { marginTop: 18, flexDirection: "row", flexWrap: "wrap", gap: 12 },
  actionCard: { width: "48%", minHeight: 128, borderRadius: 22, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, padding: 14 },
  actionIcon: { width: 42, height: 42, borderRadius: 16, backgroundColor: COLORS.brandSoft, alignItems: "center", justifyContent: "center" },
  actionTitle: { color: COLORS.text, fontSize: 15, fontWeight: "900", marginTop: 12 },
  actionSubtitle: { color: COLORS.muted, fontSize: 12, fontWeight: "700", marginTop: 4 },
  noteCard: { marginTop: 18, borderRadius: 20, backgroundColor: COLORS.brandSoft, padding: 14, flexDirection: "row", gap: 10 },
  noteText: { flex: 1, color: COLORS.brand, fontSize: 12, lineHeight: 18, fontWeight: "800" },
});

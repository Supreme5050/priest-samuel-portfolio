-- Redemption City Navigator: Live Vendor Stage 1-4 Patch
-- Safe to run. It does not delete existing data.
-- Purpose: vendor dashboard live sync, product upload, orders, and customer-vendor chat.

create extension if not exists pgcrypto;

grant usage on schema public to anon, authenticated;

-- Vendor stores live account table
create table if not exists public.vendor_stores (
  id uuid primary key default gen_random_uuid(),
  vendor_id text unique,
  owner_name text,
  phone text,
  store_name text not null,
  category text default 'General',
  area text default 'Redemption City',
  address text,
  latitude double precision,
  longitude double precision,
  status text default 'pending',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.vendor_stores
add column if not exists vendor_id text,
add column if not exists owner_name text,
add column if not exists phone text,
add column if not exists store_name text,
add column if not exists category text default 'General',
add column if not exists area text default 'Redemption City',
add column if not exists address text,
add column if not exists latitude double precision,
add column if not exists longitude double precision,
add column if not exists status text default 'pending',
add column if not exists created_at timestamptz default now(),
add column if not exists updated_at timestamptz default now();

-- Existing public vendors table used by Market Hub listings
alter table public.vendors
add column if not exists name text,
add column if not exists category text default 'general',
add column if not exists category_label text default 'Vendor',
add column if not exists area text,
add column if not exists address text,
add column if not exists latitude double precision,
add column if not exists longitude double precision,
add column if not exists phone text,
add column if not exists whatsapp text,
add column if not exists rating numeric default 4.5,
add column if not exists is_open boolean default true,
add column if not exists image_url text,
add column if not exists created_at timestamptz default now(),
add column if not exists updated_at timestamptz default now();

-- Vendor products uploaded by sellers
alter table public.vendor_products
add column if not exists vendor_id text,
add column if not exists name text,
add column if not exists description text,
add column if not exists category text default 'General',
add column if not exists price numeric,
add column if not exists unit text default 'item',
add column if not exists image_url text,
add column if not exists in_stock boolean default true,
add column if not exists created_at timestamptz default now();

-- Customer/vendor chat
create table if not exists public.chat_threads (
  id text primary key,
  vendor_id text,
  vendor_name text,
  customer_name text,
  product_id text,
  product_name text,
  last_message text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.chat_messages (
  id text primary key,
  thread_id text,
  vendor_id text,
  vendor_name text,
  customer_name text,
  product_id text,
  product_name text,
  sender_role text,
  message text not null,
  created_at timestamptz default now()
);

-- Market orders for vendor dashboard + delivery jobs
create table if not exists public.market_orders (
  id text primary key,
  vendor_id text,
  vendor_name text,
  product_id text,
  product_name text,
  customer_name text,
  quantity integer default 1,
  amount text,
  delivery_area text,
  delivery_note text,
  delivery_pin text,
  status text default 'paid',
  payment_status text default 'held',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.delivery_jobs (
  id text primary key,
  order_id text,
  vendor_id text,
  vendor_name text,
  customer_name text,
  pickup_area text,
  dropoff_area text,
  rider_name text,
  rider_phone text,
  delivery_pin text,
  status text default 'pending',
  accepted_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.delivery_jobs
add column if not exists vendor_id text,
add column if not exists rider_name text,
add column if not exists rider_phone text,
add column if not exists accepted_at timestamptz,
add column if not exists updated_at timestamptz default now();

-- RLS + grants for hackathon demo. Tighten before production.
alter table public.vendor_stores enable row level security;
alter table public.vendors enable row level security;
alter table public.vendor_products enable row level security;
alter table public.chat_threads enable row level security;
alter table public.chat_messages enable row level security;
alter table public.market_orders enable row level security;
alter table public.delivery_jobs enable row level security;

grant select, insert, update on table public.vendor_stores to anon, authenticated;
grant select, insert, update on table public.vendors to anon, authenticated;
grant select, insert, update on table public.vendor_products to anon, authenticated;
grant select, insert, update on table public.chat_threads to anon, authenticated;
grant select, insert, update on table public.chat_messages to anon, authenticated;
grant select, insert, update on table public.market_orders to anon, authenticated;
grant select, insert, update on table public.delivery_jobs to anon, authenticated;

-- Vendor stores policies
drop policy if exists "Vendor stores public select" on public.vendor_stores;
create policy "Vendor stores public select" on public.vendor_stores for select to anon, authenticated using (true);
drop policy if exists "Vendor stores public insert" on public.vendor_stores;
create policy "Vendor stores public insert" on public.vendor_stores for insert to anon, authenticated with check (true);
drop policy if exists "Vendor stores public update" on public.vendor_stores;
create policy "Vendor stores public update" on public.vendor_stores for update to anon, authenticated using (true) with check (true);

-- Vendors policies
drop policy if exists "Vendors public select" on public.vendors;
create policy "Vendors public select" on public.vendors for select to anon, authenticated using (true);
drop policy if exists "Vendors public insert" on public.vendors;
create policy "Vendors public insert" on public.vendors for insert to anon, authenticated with check (true);
drop policy if exists "Vendors public update" on public.vendors;
create policy "Vendors public update" on public.vendors for update to anon, authenticated using (true) with check (true);

-- Products policies
drop policy if exists "Vendor products public select" on public.vendor_products;
create policy "Vendor products public select" on public.vendor_products for select to anon, authenticated using (true);
drop policy if exists "Vendor products public insert" on public.vendor_products;
create policy "Vendor products public insert" on public.vendor_products for insert to anon, authenticated with check (true);
drop policy if exists "Vendor products public update" on public.vendor_products;
create policy "Vendor products public update" on public.vendor_products for update to anon, authenticated using (true) with check (true);

-- Chat policies
drop policy if exists "Chat threads public select" on public.chat_threads;
create policy "Chat threads public select" on public.chat_threads for select to anon, authenticated using (true);
drop policy if exists "Chat threads public insert" on public.chat_threads;
create policy "Chat threads public insert" on public.chat_threads for insert to anon, authenticated with check (true);
drop policy if exists "Chat threads public update" on public.chat_threads;
create policy "Chat threads public update" on public.chat_threads for update to anon, authenticated using (true) with check (true);

drop policy if exists "Chat messages public select" on public.chat_messages;
create policy "Chat messages public select" on public.chat_messages for select to anon, authenticated using (true);
drop policy if exists "Chat messages public insert" on public.chat_messages;
create policy "Chat messages public insert" on public.chat_messages for insert to anon, authenticated with check (true);

-- Orders policies
drop policy if exists "Market orders public select" on public.market_orders;
create policy "Market orders public select" on public.market_orders for select to anon, authenticated using (true);
drop policy if exists "Market orders public insert" on public.market_orders;
create policy "Market orders public insert" on public.market_orders for insert to anon, authenticated with check (true);
drop policy if exists "Market orders public update" on public.market_orders;
create policy "Market orders public update" on public.market_orders for update to anon, authenticated using (true) with check (true);

drop policy if exists "Delivery jobs public select" on public.delivery_jobs;
create policy "Delivery jobs public select" on public.delivery_jobs for select to anon, authenticated using (true);
drop policy if exists "Delivery jobs public insert" on public.delivery_jobs;
create policy "Delivery jobs public insert" on public.delivery_jobs for insert to anon, authenticated with check (true);
drop policy if exists "Delivery jobs public update" on public.delivery_jobs;
create policy "Delivery jobs public update" on public.delivery_jobs for update to anon, authenticated using (true) with check (true);
